# CommerceOS 2.0 — Codex Master Specification

**Status:** implementation specification, not implemented application. **Target:** Indian multi-tenant social-commerce retailers (initial jewellery and saree pilots). **Language:** English in engineering docs; user-facing localization English/Bengali-ready.

## Product applications
1. `apps/business-web`: premium desktop admin.
2. `apps/business-mobile`: React Native/Expo iOS+Android app for owners, managers and employees with role-driven UI.
3. `apps/storefront`: independent tenant-branded Next.js commerce website.
4. `apps/pos`: browser/PWA counter billing, online-first.
5. `apps/platform-admin`: restricted internal SaaS operations.
6. `apps/api` + `apps/worker`: NestJS modular monolith and background jobs.

## Read in order
`AGENTS.md`, `docs/PRODUCT_BLUEPRINT.md`, `docs/ARCHITECTURE.md`, `docs/WORKFORCE_PAYROLL.md`, `docs/DATA_MODEL.md`, `docs/API_CONTRACTS.md`, `docs/SCREEN_INVENTORY.md`, `docs/SECURITY_AND_TESTING.md`, `docs/ROADMAP.md`, `docs/DECISIONS.md`.

## Getting started with Codex
Open this folder as the workspace and run `prompts/01-bootstrap.md`. Each prompt is one milestone. Never generate all modules in one pass. Preserve docs as source of truth and update ADRs when choices change.

## Scope priorities
**P0**: tenancy, auth/RBAC, branch, catalog/variants, inventory ledger, manual social bookings, OMS, CRM, basic POS, storefront checkout, payment/shipping adapters, employee login and sales attribution, mobile core operations, basic invoice requirements.
**P1**: attendance, shifts, leave, approvals, salary structures, payroll preview/approval/payslips, procurement, advanced reports.
**P2**: configurable incentives, advanced payroll rules, advanced tax/accounting, subscriptions, AI, external channel connectors and offline synchronization.

Pilot use must not be treated as production readiness until security, financial reconciliation and legal compliance gates pass.
