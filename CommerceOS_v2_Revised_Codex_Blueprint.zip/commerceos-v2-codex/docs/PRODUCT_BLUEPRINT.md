# Product requirements and functional scope

## Business model and users
Multi-tenant SaaS initially piloted by two separate merchants: jewellery and saree. Each tenant may have multiple branches, staff, stock locations and an optional CommerceOS Store. Social sales are entered manually in v1; automated Meta connectors deferred. Target high order volume; design concurrency and performance from day one.

## Actors
Platform operator (cross-tenant operations with audit); tenant owner; business admin; branch manager; social sales agent; cashier; inventory staff; fulfilment staff; procurement; HR/payroll admin; accountant; storefront customer. One person may have multiple role assignments and branches. Employee access is not necessarily a paid seat until plan rules are finalized.

## Modules and acceptance outcomes
1. **Identity/tenant:** invite, login, session refresh/logout, business selection, branch context, RBAC, audit.
2. **Catalog:** categories, products, SKUs/variants, pricing, images, tax codes, custom category attributes, bulk import with validation. Jewellery: material, plating, stone, weight/design; saree: fabric, weave, color, work, blouse.
3. **Inventory:** location-level available/reserved/on-hand, receiving, adjustments, transfers, movements, low stock; no silent negative stock.
4. **Social selling:** manual session creation, product queue, customer quick find/create, temporary booking, reservation TTL, payment link request, conversion to order, expiry release. No comment scraping in v1.
5. **OMS:** order sources WEB/SOCIAL/POS/MANUAL, lifecycle, payment/fulfilment status, returns/refunds, allocations, discounts, customer communication and audited overrides.
6. **CRM:** contact records, multiple addresses, source, order history, notes, privacy preferences, deduplication review.
7. **POS:** branch register, scan/search, cart, customer, split tender if provider permits, receipt, cash open/close, return; online-first.
8. **Storefront:** merchant theme/config, SEO, responsive discovery, product, cart, checkout, payment, order history, returns request, policies, guest checkout decision pending.
9. **Procurement:** suppliers, purchase orders, goods receipt, stock and cost posting.
10. **Workforce:** employee invite/login, profile, branch/role assignments, attendance, shifts, holidays, leave balance/request/approval, salary structures, payroll, payslips. Detailed rules in WORKFORCE_PAYROLL.md.
11. **Analytics:** operational KPIs, sales attribution by employee/branch/channel, stock velocity, fulfilment aging, payroll summaries subject to permissions.
12. **Platform admin:** tenant creation/suspension, feature flags, usage, support access with audit, plan metadata (billing later).

## Nonfunctional requirements
Mobile-first daily operations; desktop for bulk administration; accessibility, low-bandwidth resilience, tenant branding, auditability, scalable asynchronous jobs, exportability, privacy, observability. Use configurable INR currency initially but schema includes currency codes.

## Out of scope initial build
External website connectors; automated WhatsApp/Instagram/Facebook comment ingestion; automated incentive settlement; AI; statutory filing; fully offline POS/mobile stock sync; native customer shopping app.
