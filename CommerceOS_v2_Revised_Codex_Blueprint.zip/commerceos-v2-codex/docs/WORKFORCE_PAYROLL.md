# Workforce, employee identity, attendance, leave, payroll and incentives

## Identity and permissions
Employee is a tenant-scoped HR record linked optionally to a global user identity; invite and onboarding link them securely. Employees can login to same Expo mobile app. Role+branch permissions decide navigation and API access. Own profile, attendance, leave, sales metrics, payslips visible only to self or explicitly authorized supervisors/HR. Separate sensitive permissions: `employee.read`, `attendance.approve`, `leave.approve`, `salary.read`, `salary.edit`, `payroll.prepare`, `payroll.approve`, `payslip.read`, `incentive.policy.manage`.

## Attendance P1
Shift assignment, scheduled vs actual clock-in/out, late/early rules, break periods, missing punches, weekly off, holiday calendars, timezones, manual correction requests, approval chain, attendance locking. V1 uses authenticated mobile check-in/out with audit and manager approval for corrections. GPS/QR/geofence optional future, only with transparent consent and safeguards. Prevent duplicate open sessions; use server time as authoritative.

## Leave P1
Configurable leave types (paid/unpaid/sick/etc), accrual/carryforward/caps, leave balance ledger, requests, overlapping-date validation, manager approvals, cancellations, holiday/weekend treatment. Policy version and effective date stored. Approved unpaid leave contributes to payroll LOP based on configured policy.

## Salary and payroll P1
Effective-dated salary structure with basic/allowances/variable components; configured pay-period proration and rounding; attendance lock; approved paid/unpaid leave; overtime/bonus/advances/deductions; statutory components only when configured and legally validated. Payroll states DRAFT -> REVIEW -> APPROVED -> FINALIZED, plus VOID/ADJUSTED with auditable corrective runs. Separate preparer and approver when enabled. Persist calculation input snapshot, policy versions, itemized line amounts, calculation version, payslip PDF metadata. Restrict payroll exports and employee bank data.

## Sales attribution P0
Each order can have one or more attribution records with employee_id, role (seller/closer/assistant), allocation basis points totaling <= 10000 per attribution group, attribution source, branch, and effective timestamp. Order `created_by` and `sold_by` are different concepts. Keep order line IDs for category/product incentives. Paid/completed/refunded statuses are event-sourced or audit-trailed. Backfill of unattributed orders requires authorization.

## Incentives P2
Policy engine can target employee/role/branch/category/product/channel, fixed-per-order, tiered progressive or slab, revenue or margin basis, targets, caps, clawbacks, split rules and effective periods. Never calculate eligibility from gross order creation alone: define qualifying states, exclusions (tax/shipping/discount/refund), and reversal handling. Freeze approved incentive statements; issue adjustment entries for late refunds; include finalized incentives as payroll component only through approved import. Do not silently rewrite historical statements.

## Acceptance scenarios
1. Employee can see own attendance, leave, sales but not coworker salary.
2. Manager sees only assigned branches and cannot grant themselves payroll rights.
3. Two check-ins without checkout rejected or reconciled explicitly.
4. Leave overlapping approved leave rejected; cancelled leave restores balance via ledger.
5. Payroll run can be reproduced from frozen inputs and policy versions.
6. Order attributed to employee A remains auditable if employee transfers branch or leaves.
7. Refund after incentive close produces adjustment, not mutation of old statement.
8. No payslip accessible by guessed ID or cross-tenant URL.
