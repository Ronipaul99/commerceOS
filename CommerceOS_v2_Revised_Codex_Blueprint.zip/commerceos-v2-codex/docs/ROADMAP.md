# Milestone roadmap (scope-driven, not guaranteed calendar)

M0 Discovery/UX: merchant workflows, policy decisions, Figma tokens, user journeys, wireframes, test cases. Deliver role matrix and acceptance criteria.
M1 Foundation: monorepo, API, database, CI, auth, tenant/branch RBAC, app shells (web/mobile/store/POS/platform), seeded demo tenants. Gate: cross-tenant tests.
M2 Catalog/Inventory: SKU/variants, image upload, stock ledger, reservations, branch balances, web/mobile stock screens. Gate: concurrency tests.
M3 OMS/Social/CRM: manual live session, bookings, orders, customer, attribution from day one, mobile quick order. Gate: end-to-end social booking to order.
M4 Storefront/POS: tenant themes, cart/checkout, payments via sandbox provider, shipping adapter, POS, invoices. Gate: web and counter orders stock reconciliation.
M5 Workforce identity/mobile: employee invite/login, permissions, branch assignments, own/team dashboards, own sales reports, audit. Gate: employee privacy tests.
M6 Attendance/Leave: shifts, holidays, punches, corrections, leave policies/approvals, manager mobile UI. Gate: policy/overlap tests.
M7 Payroll: salary effective dates, pay period, LOP, draft/approval/finalization, payslips, exports; validate local compliance. Gate: deterministic payroll and separation of duties.
M8 Pilot/hardening: migrations, merchant UAT, security, monitoring, load tests, backups, training, incident playbooks.
M9 Future: incentives policy engine, performance payout adjustment, external website connectors, advanced accounting, SaaS billing, AI, offline-first sync.

Sequence can overlap with a staffed team but preserve dependency gates. Do not promise dates without staffing and scope sizing.
