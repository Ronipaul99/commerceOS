# Architectural decisions and unresolved product questions

## Confirmed
ADR-001: Separate Business Web, Business Mobile, Storefront, POS, Platform Admin; shared versioned API.
ADR-002: React Native + Expo mobile, single app for owner/employee with role-aware navigation.
ADR-003: NestJS modular monolith, PostgreSQL, Prisma, Redis/BullMQ, outbox.
ADR-004: Shared-schema multi-tenancy with strict tenant and branch authorization.
ADR-005: Ledger-based stock, atomic reservation, payment webhook authority.
ADR-006: Employee sales attribution P0, attendance/leave/payroll P1, incentive policy engine P2.
ADR-007: External connectors deferred; API/event boundaries maintained.
ADR-008: Payroll approval snapshots immutable and sensitive permissions segregated.
ADR-009: Storefront independent deployment and branding; storefront shares backend API, not web app code.
ADR-010: Online-first POS and mobile stock operations; offline drafts only initially.

## Open — decide before corresponding milestone
- Jewellery type (imitation vs precious metals), serialized stock, weight pricing and hallmark needs.
- Salary structure, calendar days vs working days proration, paid leave rules, weekly offs, overtime, advances, statutory eligibility, pay-cycle cutoffs.
- Employee attendance manual vs QR vs geofencing (initial default: authenticated check-in/out and correction approval).
- Sales attribution single seller vs split, refunds, incentive basis/eligibility, revenue vs margin, attribution after employee exit.
- Auth method (phone OTP/email/password), OTP/SMS provider and cost; payment/shipping providers.
- Guest checkout, customer login method, domains, storefront theme variation.
- Tenant pricing/seat/order/branch limits; hosting, scale/peak traffic and retention.
- Employee device policies and privacy/consent, support impersonation restrictions.
