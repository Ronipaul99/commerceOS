# Architecture and repo topology

```text
commerceos/
  apps/
    api/                   # NestJS HTTP + auth + modules
    worker/                # BullMQ outbox/notifications/expiry
    business-web/          # Next.js or React SPA, admin
    business-mobile/       # Expo React Native, owner and employee
    storefront/            # Next.js tenant branded customer web
    pos/                   # React PWA online-first
    platform-admin/        # Restricted operations UI
  packages/
    api-contracts/         # Zod/OpenAPI-generated public DTOs
    api-client/            # Fetch client with typed errors
    design-tokens/         # Shared semantics, not DOM components
    ui-web/                # Web-only reusable UI
    config/                # tsconfig, eslint, tooling
  prisma/                  # Schema, migrations, seeds
  docs/; prompts/; infra/
```

## Backend domain modules
Auth, Tenant, Branch, AccessControl, Catalog, Pricing, Inventory, Reservation, Customer, SocialSale, Order, Payment, Shipping, POS, Supplier, Purchase, Workforce, Attendance, Leave, Payroll, Incentives (schema/attribution groundwork only P0), Analytics, Notifications, Audit, Files, PlatformOps. Modules communicate through explicit service contracts and domain events. Avoid premature distributed microservices.

## Mobile architecture
Expo Router, TypeScript, TanStack Query, Zustand for local UI, SecureStore for refresh/session credentials, push token registration, camera/barcode, secure deep links. Role/permission-driven navigation, branch switching and employee self-service. Offline draft queue only for non-financial, non-stock authoritative actions; clear pending sync status.

## Multi-tenancy
All tenant-owned tables have tenant_id, branch-scoped records branch_id. Authenticate user -> tenant membership -> active tenant -> scoped branch grants. All repository queries filter tenant; consider RLS as defense in depth after pool/session analysis. Platform admin access separate audited trust boundary.

## Transaction workflows
- Social booking: search SKU -> reserve stock atomically -> associate customer and salesperson -> expiry or verified payment -> order -> fulfilment.
- Store order: public cart -> server price/tax/stock validation -> reservation -> payment intent -> verified webhook -> confirmation -> fulfilment.
- POS: select branch -> cart -> validated price -> payment -> invoice -> ledger posting; record cashier vs selling employee separately.
- Return/refund: authorization -> reverse stock if resellable -> provider refund verification -> reverse eligible sales attribution -> incentive adjustments later.
- Attendance: check in/out -> manager corrections/approvals -> period lock -> payroll inputs.
- Payroll: effective salary -> attendance/leave/overtime inputs -> draft calculation -> review/approval -> finalized immutable payslip; no direct bank payouts in initial version.

## Reliability
DB transaction + outbox for business events; workers retry idempotently with DLQ; request idempotency keys for booking, order, payment and payroll finalization; webhook signature and replay protection; structured logs, traces, metrics, backups, PITR, rate limits and health endpoints.

## Integration-ready, not integration-implemented
Stable `/api/v1` resource APIs, outbox events, provider adapter interfaces, merchant-scoped API credentials as future extension. No external connector UI or worker in P0.
