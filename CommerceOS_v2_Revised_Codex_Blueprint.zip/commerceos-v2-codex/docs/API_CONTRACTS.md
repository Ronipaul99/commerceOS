# API contract v1 (illustrative routes; validate via OpenAPI)

Base `/api/v1`; JSON error `{code,message,details,requestId}`; cursor pagination and filtering; explicit ISO timestamps and integer paise. Auth derives tenant context from verified membership; branch scope checked server-side. Idempotency-Key required on financial/stock mutation endpoints. Return correct 401/403/409/422 codes.

## Identity/tenancy
`POST /auth/login`, `POST /auth/refresh`, `POST /auth/logout`, `GET /me`, `GET /me/memberships`, `POST /me/active-context`, `GET /me/permissions`, `POST /employees/invitations`.

## Catalog and stock
`GET/POST /products`, `GET/PATCH /products/:id`, `GET/POST /variants`, `GET /inventory/balances`, `POST /inventory/adjustments`, `POST /inventory/transfers`, `GET /inventory/movements`, `POST /reservations`, `POST /reservations/:id/release`.

## Orders/social/POS
`GET/POST /orders`, `GET /orders/:id`, `POST /orders/:id/confirm`, `POST /orders/:id/fulfil`, `POST /orders/:id/cancel`, `POST /orders/:id/returns`, `GET/POST /social-sessions`, `POST /social-sessions/:id/bookings`, `POST /social-bookings/:id/convert`, `GET /pos/registers`, `POST /pos/sales`, `POST /pos/shifts/:id/close`.

## Customers, suppliers, storefront
`GET/POST /customers`, `GET /customers/:id`, `GET/POST /suppliers`, `GET/POST /purchase-orders`, `POST /goods-receipts`; public storefront `GET /store/:tenantSlug/catalog`, `GET /store/:tenantSlug/products/:slug`, `POST /store/:tenantSlug/carts`, `POST /store/:tenantSlug/checkout`, `GET /store/:tenantSlug/config`. Use safe public DTOs, never internal salary/stock cost.

## Payments
`POST /payments/intents`, `POST /webhooks/payments/:provider` (signature validated, idempotent), `GET /payments/:id`, `POST /refunds`. Never trust frontend success alone.

## Workforce
`GET/POST /employees`, `GET/PATCH /employees/:id`, `GET /employees/me`, `GET /employees/me/sales`, `GET /attendance/me`, `POST /attendance/check-in`, `POST /attendance/check-out`, `POST /attendance/corrections`, `POST /attendance/corrections/:id/approve`, `GET /attendance/team`, `GET /leave/balances/me`, `GET/POST /leave/requests`, `POST /leave/requests/:id/approve`, `POST /leave/requests/:id/reject`, `GET/POST /salary-structures`, `GET/POST /payroll/runs`, `POST /payroll/runs/:id/calculate`, `POST /payroll/runs/:id/approve`, `POST /payroll/runs/:id/finalize`, `GET /payslips/me`, `GET /payslips/:id/download`. Incentive P2: `GET/POST /incentive-policies`, `POST /incentives/calculate`, `GET /incentives/me`.

## Event contracts
`inventory.reserved`, `inventory.released`, `order.created`, `order.paid`, `order.refunded`, `order.attribution.changed`, `attendance.corrected`, `leave.approved`, `payroll.finalized`; include `eventId`, `tenantId`, `aggregateId`, `version`, `occurredAt`, `payload` with schema version. Outbox ensures delivery; consumers idempotent.
