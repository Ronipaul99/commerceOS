# Relational data model — conceptual Prisma/PostgreSQL schema

All tenant-owned tables include `id UUID`, `tenant_id UUID`, `created_at`, `updated_at` (plus deleted_at only where justified). Tenant+ID/slug/SKU composite unique indexes and foreign key discipline. Money stored as BIGINT paise, currencies ISO code, tax rates decimal. Tenant isolation tested on every relation. Do not blindly generate all tables in milestone 1.

## Core and auth
`tenants`, `tenant_settings`, `branches`, `stock_locations`, `users`, `tenant_memberships`, `roles`, `permissions`, `role_permissions`, `user_role_assignments`, `sessions`, `audit_logs`, `files`.

## Catalog/inventory
`categories`, `products`, `product_variants`, `product_attributes`, `product_media`, `price_lists`, `prices`, `stock_balances`, `stock_movements`, `stock_reservations`, `stock_transfers`, `stock_counts`, `stock_adjustments`.

## Commerce
`customers`, `customer_addresses`, `customer_notes`, `social_sessions`, `social_bookings`, `carts`, `cart_items`, `orders`, `order_items`, `order_status_history`, `order_sales_attributions`, `payments`, `payment_events`, `refunds`, `shipments`, `shipment_events`, `returns`, `return_items`, `invoices`, `pos_registers`, `pos_shifts`, `pos_tenders`.

## Procurement
`suppliers`, `purchase_orders`, `purchase_order_items`, `goods_receipts`, `goods_receipt_items`.

## Workforce
`employees` (user_id nullable until invitation accepted; employment status, hire/exit dates), `employee_branch_assignments`, `employee_documents`, `shifts`, `shift_assignments`, `attendance_records`, `attendance_corrections`, `holiday_calendars`, `holidays`, `leave_types`, `leave_policies`, `leave_policy_versions`, `leave_balance_ledger`, `leave_requests`, `salary_structures`, `salary_structure_versions`, `salary_components`, `payroll_periods`, `payroll_runs`, `payroll_items`, `payroll_item_components`, `payroll_input_snapshots`, `payslips`, `payroll_adjustments`, `incentive_policies`, `incentive_policy_versions`, `incentive_calculations`, `incentive_entries`, `incentive_adjustments`.

## Platform and infrastructure
`storefront_configs`, `tenant_domains`, `notification_templates`, `notifications`, `device_push_tokens`, `idempotency_keys`, `outbox_events`, `job_failures`, `feature_flags`, `plan_definitions`, `tenant_plan_assignments` (billing deferred).

## Important constraints
- Unique SKU per tenant; unique branch code per tenant; employee code per tenant.
- Stock balances unique `(tenant_id, location_id, variant_id)`; stock reservations unique idempotency key per tenant.
- Order number unique per tenant and source; provider event IDs unique per provider/account.
- Each attribution references tenant-consistent order, employee and optionally order item. Enforce allocation split policy transactionally.
- Attendance: no overlapping active sessions per employee and shift; corrections audited.
- Leave balance derived from ledger; never update without a ledger entry.
- Salary versions effective-dated and nonoverlapping for employee/policy as applicable.
- Payroll run unique `(tenant_id, period_id, run_type, revision)`; finalized rows immutable; adjustment references prior run.
- Storefront domain unique globally after verification.

## Indexes
`tenant_id,branch_id,status,created_at` for orders; `tenant_id,employee_id,date` attendance; `tenant_id,employee_id,period_id` payroll; `tenant_id,variant_id,location_id` inventory; outbox status/next_attempt. Avoid storing sensitive bank account plaintext.
