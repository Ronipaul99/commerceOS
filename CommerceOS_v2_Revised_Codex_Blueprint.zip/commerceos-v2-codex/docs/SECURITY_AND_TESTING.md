# Security, privacy, quality and launch gates

## Access/security
Use passwordless/OTP or password login only after auth decision; hashed passwords where used, MFA for owner/payroll administrators, secure session rotation/revocation, brute-force throttling, signed invitation expiry. RBAC enforced at API, row and branch level. No privilege escalation by client-selected role. Audit sensitive reads/downloads of salary documents. Private file URLs short-lived and tenant-scoped. Encrypt personal identifiers, bank details and provider secrets; redact logs. Consent, retention and deletion/export policy for customers and employees.

## Mandatory tests
Tenant A cannot read/change Tenant B products/orders/staff/payroll; employee cannot see peer payslip; branch manager cannot access other branch; cancelled orders release reservations; concurrent checkout cannot oversell; repeated payment webhook not double-credit; refund reverses stock and eligible attribution according to policy; leave balance ledger reconciles; attendance cannot double check-in; payroll preview deterministic with fixed inputs; finalized payroll immutable; approved salary adjustments audited; frontend permission denied/empty/loading states; mobile login/logout and branch switch; storefront order placement and POS checkout e2e.

## CI/CD gates
Lint, TS check, unit tests, integration tests against ephemeral PostgreSQL, migration validation, dependency scanning, API schema diff, smoke e2e. Backups restore tested; production secrets manager, rate limiting, alerting, structured audit retention, data exports, disaster recovery plan. Payment and payroll require human QA signoff.

## Compliance
India-specific GST invoice, PF, ESI, professional tax, TDS, wage and leave requirements vary by jurisdiction, establishment and employee eligibility. Do not infer legal rates or auto-enable deductions. Confirm with qualified accountant/payroll/legal specialist before production and version configuration per tenant.
