# UI/UX screen inventory and navigation

Counts are planning targets, not 1:1 routes; many can be dialogs, tabs or reusable flows. Design mobile 390px and 430px, desktop 1280/1440px, POS tablet 768px. Accessibility, empty/error/loading/permission denied, and low-bandwidth states required.

## Business Web (~67 screens)
Auth/onboarding (6): login, forgot, verify, reset, register, setup wizard.
Dashboard (3): overview, sales, pending actions.
Catalog (5): list, editor, detail, categories, bulk import.
Inventory (6): overview, branch stock, adjust, transfer, movements, count.
OMS (6): list, detail, manual create, packing, cancellations/returns, refunds.
Social (5): dashboard, session, booking, queue, conversion.
CRM (4): directory, profile, editor, segments.
Purchasing (5): suppliers, supplier detail, PO list, PO editor, goods receipt.
Employees/Workforce (13): directory, employee detail, invite, roles, attendance register, shifts, correction approvals, leave requests, leave policy, salary structures, payroll runs, payroll detail, payslip review.
Reports (5): sales, product, stock, customer, collections.
Settings (9): business, branches, payments, shipping, invoice/tax, notifications, security, holidays, payroll configuration.
Count above = 67; adjust route grouping if design requirements change.

## Business Mobile (~46 screens)
Auth/workspace (4): login, tenant select, branch select, onboarding.
Home (3): dashboard, notification center, quick actions.
Orders (5): list, detail, create, collect payment, packing.
Live social (6): sessions, start, catalog, quick booking, queue, summary.
Inventory (5): stock, lookup, editor, barcode, adjustment.
CRM (3): search, profile, quick add.
Core operations (4): tasks, reports, settings, profile.
Workforce (16): employee home, directory, profile, invite/role, check-in/out, my attendance, team attendance, leave apply, leave balance/history, leave approval, salary structure, payroll overview, payroll approval, my payslips, my sales performance, incentive breakdown (P2).

## POS (7)
Terminal login, new sale, customer selector, payment, receipt, transactions/returns, cash register close.

## Storefront (25)
Homepage, shop all, category, search, product, wishlist, collection, cart, address, shipping, payment, success, failure, login, verify, account, profile, addresses, order history, order detail/tracking, return request, about, contact, FAQ/policies, reviews.

## Platform admin (7)
Login, tenants, tenant create, tenant detail, plan definitions, usage/health, support/audit.

## UX rules
Mobile bottom tabs Home/Orders/Live/Inventory/More, plus contextual quick-order action. Employee sees role-specific home and actions, not inaccessible tabs. Payroll details only behind explicit permission. Live sale booking target 3–4 taps for returning customer with known SKU. Web sidebar grouped Overview, Sales, Catalog, Inventory, Customers, Workforce, Purchasing, Reports, Settings. Storefront design tokens/theme separate from business UI. No fabricated sales analytics.
