# Codex milestone — 04-oms-social

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Implement customers, social sessions, quick booking, OMS, order attribution (created_by vs seller, multi-attribution), booking expiry worker, payment state skeleton. Build mobile Live Sale Mode, quick order, orders and web OMS. Test refund/cancel attribution handling and idempotency.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
