# Codex milestone — 07-payroll

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Implement salary structure effective versions, payroll periods, configurable proration/LOP, preview, review, approval, immutable finalization, adjustment and payslip download. Include payroll RBAC, audit, deterministic calculation tests, legal-configuration TODOs. Do not hardcode statutory rates.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
