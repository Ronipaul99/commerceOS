# Codex milestone — 06-workforce

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Implement employee profile/invite/branch roles, mobile employee dashboard, own sales performance and privacy rules; attendance shifts/check-in/out/corrections, leave types/balance ledger/requests/approvals. Implement web and mobile manager screens. Add cross-tenant, own-data and policy tests.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
