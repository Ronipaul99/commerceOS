# Codex milestone — 01-bootstrap

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Scaffold pnpm/Turborepo monorepo with apps api, worker, business-web, business-mobile (Expo), storefront, pos, platform-admin, packages api-contracts/api-client/design-tokens/ui-web/config. Add Docker Compose Postgres/Redis, CI, lint/typecheck/test scripts, health endpoint, env example. No domain features yet.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
