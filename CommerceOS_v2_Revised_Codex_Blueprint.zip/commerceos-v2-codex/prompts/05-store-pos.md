# Codex milestone — 05-store-pos

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Implement separate tenant-branded storefront, cart, checkout, provider payment sandbox/webhook verification, shipping adapter, invoices and online-first POS. Build responsive storefront and counter POS; stock reconciliation and e2e tests.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
