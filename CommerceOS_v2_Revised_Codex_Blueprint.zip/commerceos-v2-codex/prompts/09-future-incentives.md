# Codex milestone — 09-future-incentives

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Design only unless explicitly authorized: incentive policy versioning, attribution eligibility, progressive tiers, splits, refund clawbacks, approval and payroll import. Propose migrations and tests before coding. External connectors remain separate future milestone.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
