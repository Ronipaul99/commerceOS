# Codex milestone — 08-hardening

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Add analytics, procurement completion, notifications, accessibility, backups, performance/security tests, CI, deployment docs, merchant UAT scenarios. Do not implement incentive engine or external integrations.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
