# Codex milestone — 03-catalog-inventory

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Implement catalog, variant/category attributes for jewellery and sarees, media storage adapter, inventory ledger, balances, reservations, adjustments and transfer APIs. Build web inventory/catalog and mobile stock lookup/editor/barcode flows. Prove concurrent reservations cannot oversell.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
