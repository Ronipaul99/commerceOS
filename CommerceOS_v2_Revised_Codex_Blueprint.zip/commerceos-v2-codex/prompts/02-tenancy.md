# Codex milestone — 02-tenancy

Read `AGENTS.md` and all `docs/*.md`, inspect existing repository, then present a brief implementation plan, files affected, migrations and acceptance tests. **Task:** Implement tenant/user/membership/branch/role/permission/auth/session schema and APIs. Add employee user invitation skeleton and server-side tenant/branch RBAC. Build role-aware mobile and web app shells. Write tenant isolation and privilege escalation tests.

Constraints: change only this milestone; tenant isolation and employee/payroll privacy mandatory; use typed contracts, idempotency and audited financial changes; update OpenAPI/docs/tests; run lint/typecheck/tests and report actual results, blockers and next steps. Do not invent external credentials or declare production readiness.
