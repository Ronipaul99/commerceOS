# CommerceOS 2.0 — mandatory Codex instructions

You are an engineering agent implementing a multi-tenant, mobile-first retail SaaS. Read all `docs/*.md` before changes. Deliver one milestone at a time. Propose a plan, list changed files, implement, test, and report blockers; never claim unrun tests passed.

## Architecture invariants
- Separate deployable business web, React Native mobile, storefront, POS, platform admin; shared typed public API contracts only. No frontend DB access.
- Backend: NestJS modular monolith, PostgreSQL/Prisma, Redis/BullMQ, outbox worker. Multi-tenant shared-schema tables with tenant_id and scoped uniqueness. Tenant identity resolved from verified membership, never request body. Branch permissions enforced.
- Permissions are server-side resource/action/scope grants, not UI visibility checks. Employees and owners authenticate to same tenant workforce; UI navigation is role-aware.
- Every order records actor, source, branch, and explicit immutable sales attribution entries (with future split capability). Employee performance excludes cancelled/refunded items by policy and retains history.
- Stock is changed only by transactional stock movements and reservations. Avoid overselling with DB constraints/locks; reservation expiry and idempotency. Payment paid status only from verified provider event or authorized audited offline reconciliation.
- Storefront is separately deployable, tenant-branded, consumes versioned commerce APIs. Integration Hub is NOT built now; future connectors use events and APIs.
- Payroll is sensitive: effective-dated salary policies, attendance and leave inputs, draft previews, maker-checker approval, immutable finalized payroll snapshots, audited adjustments. Do not hardcode statutory India deductions or assume a single proration rule; use configurable policies and require legal review before launch.
- Amounts in integer paise; quantities/taxes decimal-safe; timezone-aware timestamps in UTC, business local calendar/timezone configurable. No hardcoded sample metrics in real dashboard.
- Secrets never committed. Encrypt provider credentials and private documents, restrict payslips, redact PII, use least privilege, audit payroll, leave, salary, refund and stock changes.
- Strict TS, schema validation, OpenAPI, migrations, seed data, lint/typecheck/unit/integration/e2e and tenant-isolation tests. Accessible premium UX with loading/empty/error states, i18n-ready.

## Execution discipline
- Follow `prompts/` in sequence. Build vertical slices and use mock adapters until credentials exist.
- No Shopify/WooCommerce integrations, Meta automation, AI, incentive payouts, full accounting or offline authoritative stock in initial milestones.
- Update docs and tests with schema/API changes; record unresolved decisions in `docs/DECISIONS.md`.
